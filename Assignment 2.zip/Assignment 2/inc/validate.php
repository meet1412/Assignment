<?php
require '../database.php';
$database = new database();

$username = $_POST['uname'];
$password = hash('sha512', $_POST['pass']);

$sql = "SELECT id FROM users 
WHERE username = '$username' AND password = '$password'";

$result = $database->con->query($sql);
$count = $result -> num_rows;

if ($count == 1){
	echo 'Logged in Successfully.';
	$row = $result->fetch();
		session_start();
		$_SESSION['id'] = $row['id'];
		Header('Location: ../view.php');
}
else {
	echo 'Invalid Login';
	Header('Location: ../view.php');
}
$conn = null;
?>
